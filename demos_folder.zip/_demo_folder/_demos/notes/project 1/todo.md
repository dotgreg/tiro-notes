=== HEADER ===
created: 1771626248543
updated: 1771626714840
=== END HEADER ===
- [ ] todo 1
- [ ] todo 2
- [ ] todo 3
- [ ] todo 4
![800-450fossfjordur-609160681](.resources/800-450fossfjordur-609160681-2026-1-20-23h31m-53s.jpg)


