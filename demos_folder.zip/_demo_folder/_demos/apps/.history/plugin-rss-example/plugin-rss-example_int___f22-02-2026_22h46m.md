=== HEADER ===
created: 1771800303480
updated: 1771800387668
=== END HEADER ===
[[feed]] 
courInt | https://www.courrierinternational.com/feed/all/rss.xml | _🗳️ polit
lemonde | https://www.lemonde.fr/rss/une.xml | _🗳️ polit
krydspresso | https://seenthis.net/people/framasoft/feed |     _✨ quali,_🕹️ geek
dansLesAlgos | https://danslesalgorithmes.net/feed/ |     _✨ quali,_🗳️ polit,_🕹️ geek

offshorewind | https://www.offshorewind.biz/feed/ |     _⚡ener
tumblr inspi1 | https://melanocetuss.tumblr.com/rss |     _🏛️ archi, _🖼️inspi
archi brut 1 | https://www.pinterest.com/topboj/brutalism.rss |     _🏛️ archi, _🖼️inspi
conversation | https://theconversation.com/articles.atom?language=en |     _✨ quali,_🗳️ polit,_⚛ science
conversation_fr | https://theconversation.com/fr/articles.atom |     _✨ quali,_🗳️ polit
404 | https://www.404media.co/rss |     _✨ quali,_🕹️ geek
offshoreEngin | https://www.oedigital.com/offshore-wind?format=feed |     _⚡ener
marineEner | https://renewablesnow.com/news/news_feed/?source=marine |     _⚡ener
offshore2 | https://renewablesnow.com/news/news_feed/?source=wind%20offshore |     _⚡ener
natura sciences | http://feeds.feedburner.com/NaturaSciences |     _⚛ science
ICN | https://insideclimatenews.org/rss |     _⚛ science,_⚡ener
archi pin1 | https://fr.pinterest.com/archdigest/exciting-architecture-%2B-design.rss |     _🏛️ archi, _🖼️inspi

brutalism flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=12792144@N00&lang=fr-fr&format=rss_200| _🖼️inspi 
bauhaus flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=35863436@N00&lang=fr-fr&format=rss_200| _🖼️inspi 
hist fr flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=1866488@N24&lang=fr-fr&format=rss_200| _🖼️inspi 
urbex1 flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=18529420@N00&lang=fr-fr&format=rss_200| _🖼️inspi 
urbex2 flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=1520590@N24&lang=fr-fr&format=rss_200| _🖼️inspi 
interior flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=22812088@N00&lang=fr-fr&format=rss_200| _🖼️inspi
soviet flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=391009@N25&lang=fr-fr&format=rss_200| _🖼️inspi
industry flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=35249250@N00&lang=fr-fr&format=rss_200| _🖼️inspi
furniture flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=687802@N22&lang=fr-fr&format=rss_200| _🖼️inspi
landscapes flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=2297498@N20&lang=fr-fr&format=rss_200| _🖼️inspi
postcards flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=16441431@N00&lang=fr-fr&format=rss_200| _🖼️inspi
old illustrations flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=1585985@N23&lang=fr-fr&format=rss_200| _🖼️inspi
old ad flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=73616815@N00&lang=fr-fr&format=rss_200| _🖼️inspi
vintage typo flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=66774125@N00&lang=fr-fr&format=rss_200| _🖼️inspi
vintage photos flickr | https://www.flickr.com/services/feeds/groups_pool.gne?id=46226460@N00&lang=fr-fr&format=rss_200| _🖼️inspi

figaro | https://www.lefigaro.fr/rss/figaro_actualites.xml |     _droitardé
lepoint | https://www.lepoint.fr/24h-infos/rss.xml |     _droitardé

⭐️mondiplo | https://www.monde-diplomatique.fr/recents.xml | _🗳️ polit, _✨ quali, 
arretimg | https://api.arretsurimages.net/api/public/rss/all-content | _✨ quali
MoneyVox | https://www.moneyvox.fr/actu/rss.php | _💲econo


euroAv | https://www.euractiv.fr/?feed=mcfeed | _🗳️ polit

FP | https://foreignpolicy.com/feed/  | _🗳️ polit
FT | https://www.ft.com/news-feed?format=rss  | _🗳️ polit
Politico-ener | https://rss.politico.com/energy.xml | _🗳️ polit, _⚡ener
Politico-us | https://rss.politico.com/politics-news.xml | _🗳️ polit
Polemia | http://www.polemia.com/feed/| _🗳️ polit
Noiriel | https://noiriel.wordpress.com/rss| _🗳️ polit, _✨ quali 

ConnEner | https://www.connaissancedesenergies.org/rss.xml | _⚡ener
actuenv | https://www.actu-environnement.com/flux/rss/environnement/| _⚡ener
enerGeek | https://lenergeek.com/feed/ | _⚡ener

philomag | http://www.philomag.com/rss-breves.php |  _🧠 psy
CaroKintzPhilo | https://www.mezetulle.fr/feed/ |  _🧠 psy
nopensées | http://nospensees.com/feed |  _🧠 psy
collegeFr | https://laviedesidees.fr/spip.php?page=backend |  _🧠 psy

journalCNRS| https://lejournal.cnrs.fr/rss | _⚛ science,


hn | https://news.ycombinator.com/rss |  _🕹️ geek
korben | https://korben.info/feed |  _🕹️ geek
planetGnu |http://planet.gnu.org/rss20.xml  |  _🕹️ geek
sebsauv | https://sebsauvage.net/links/?do=dailyrss |  _🕹️ geek, 
Lhv | https://lehollandaisvolant.net/rss.php?mode=links  |  _🕹️ geek, _✨ quali
samfish | https://sammyfisherjr.net/Shaarli//?do=rss  |  _🕹️ geek
lixfr | https://linuxfr.org/liens.atom |  _🕹️ geek
developpez | http://www.developpez.com/rss.php |  _🕹️ geek
frenchweb| http://feeds.feedburner.com/frenchweb |  _🕹️ geek
SimonWilln |  https://simonwillison.net/atom/everything/ |  _🕹️ geek,   _✨ quali
zataz | http://feeds.feedburner.com/ZatazNews |  _🕹️ geek 
shneier | https://www.schneier.com/blog/index.xml |  _🕹️ geek , _✨ quali
comptoir | https://comptoir.org/feed/ | _🗳️ polit, _✨ quali

canard | https://www.canardpc.com/cat%C3%A9gorie/jeu-video/feed |  _🕹️ geek
canardVid | https://invidious.fdn.fr/feed/channel/UCFe-p93CVJ13v3GM0hIzYNg |  _🕹️ geek
futura1 | https://www.futura-sciences.com/rss/actualites.xml | _⚛ science,
futura-doss |  https://www.futura-sciences.com/rss/dossiers.xml | _⚛ science, 



ploum|  https://ploum.net/atom_en.xml | _🕹️ geek, _✨ quali


kek | http://blog.zanorg.com/rss/fil_rss.xml |  _😄fun
Datasci-feat | https://towardsdatascience.com/feed/tagged/tds-features | _🕹️ geek,
Datasci-pick | https://towardsdatascience.com/feed/tagged/editors-pick | _🕹️ geek,
next | https://next.ink/feed/briefonly?rsskey=234766-e89c0cfb-1ffc-4eb9-ac96-496c6c197b42 | _🕹️ geek
informé | https://www.linforme.com/rss/all_headline.xml |  _✨ quali




archdaily |  http://feeds.feedburner.com/Archdaily | _🏛️ archi
dezeen |  https://www.dezeen.com/feed/ | _🏛️ archi 


xcdc|  http://xkcd.com/rss.xml | _😄fun
sad_useless |  https://www.sadanduseless.com/feed/ | _😄fun

eatliver |  https://www.eatliver.com/feed | _😄fun
awkwardFamfot|  https://awkwardfamilyphotos.com/feed/ | _😄fun
devhumour |   https://devhumor.com/feed | _😄fun

R_franc |  https://old.reddit.com/r/france/.rss | _💬reddit
⭐️R_mondeDiplo |  https://old.reddit.com/domain/monde-diplomatique.fr/.rss | _💬reddit, _✨ quali, 
R_ecologie |  https://old.reddit.com/r/ecologie/.rss | _💬reddit
R_Antitaff | https://www.reddit.com/r/antitaff/.rss | _💬reddit
R_AskHistorians | https://www.reddit.com/r/AskHistorians/.rss | _💬reddit
R_geothermal | https://www.reddit.com/r/geothermal/.rss | _💬reddit
R_AskSocialScience | https://www.reddit.com/r/AskSocialScience/.rss | _💬reddit
R_Pasdequestionidiote | https://www.reddit.com/r/Pasdequestionidiote/.rss | _💬reddit
R_coco | https://www.reddit.com/r/communism/.rss | _💬reddit
R_askeconomics | https://www.reddit.com/r/askeconomics/.rss | _💬reddit
R_giscardpunk | https://www.reddit.com/r/giscardpunk/.rss | _💬reddit, _🖼️inspi, _😄fun

R_memesdecentralises | https://www.reddit.com/r/memesdecentralises/.rss | _💬reddit, _😄fun
R_rance| https://www.reddit.com/r/rance/.rss | _💬reddit, _😄fun
R_linkedinfr| https://www.reddit.com/r/linkedinfr/.rss | _💬reddit, _😄fun
R_troppeurdedemander| https://www.reddit.com/r/troppeurdedemander/.rss | _💬reddit, _😄fun
R_francedetendue | https://www.reddit.com/r/francedetendue/.rss | _💬reddit, _😄fun
R_contrepeterie | https://www.reddit.com/r/contrepeterie/.rss | _💬reddit, _😄fun
R_rienabranler | https://www.reddit.com/r/rienabranler/.rss | _💬reddit, _😄fun
R_besoindeparler | https://www.reddit.com/r/besoindeparler/.rss | _💬reddit, _😄fun

R_memes| https://www.reddit.com/r/memes/.rss | _💬reddit, _😄fun
R_jeuxvideo | https://www.reddit.com/r/jeuxvideo/.rss | _💬reddit, _😄fun,_🕹️ geek


repterre | https://reporterre.net/spip.php?page=backend-simple | _🗳️ polit
legarofi | https://www.legorafi.fr/feed/|   _✨ quali

[[feed]]