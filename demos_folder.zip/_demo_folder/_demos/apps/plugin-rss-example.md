=== HEADER ===
created: 1771800303480
updated: 1771800415586
=== END HEADER ===
[[feed]] 
courInt | https://www.courrierinternational.com/feed/all/rss.xml | _🗳️ polit
lemonde | https://www.lemonde.fr/rss/une.xml | _🗳️ polit
FP | https://foreignpolicy.com/feed/  | _🗳️ polit
FT | https://www.ft.com/news-feed?format=rss  | _🗳️ polit
Politico-ener | https://rss.politico.com/energy.xml | _🗳️ polit, _⚡ener
Politico-us | https://rss.politico.com/politics-news.xml | _🗳️ polit
[[feed]]